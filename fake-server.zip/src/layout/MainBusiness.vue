<template>
  <section id="mainBusiness">
    <div class="mainbusiness_wrap">
      <h3>Samhwa<br />Business Area</h3>

      <div class="mainbusiness_content">
        <p>
          친환경에 바탕을 둔, 글로벌 경쟁력을 갖춘<br />
          종합도료기업 삼화페인트
        </p>

        <div class="mainbusiness_slider_wrap01">
          <ul class="mainbusiness_slider01">
            <li class="mainbusiness_slider_active mainBusiness-slide-img-01">
              <a href="#">
                <strong
                  >건축용 <br /><span
                    >70년 전통의 대한민국 No.1 건축용 페인트</span
                  ></strong
                ></a
              >
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-02">
              <a href="#">
                <strong
                  >방수 &#47; 바닥용 <br /><span>
                    옥상과 지하주차장, 운동장 바닥까지 견고한 품질의 방수 바닥용
                    페인트
                  </span></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-03">
              <a href="#">
                <strong
                  >내화 &#47; 방염 <br /><span
                    >강력한 내화성능과 재해 방지를 위한 내화&#47;방염
                    페인트</span
                  ></strong
                ></a
              >
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-04">
              <a href="#">
                <strong
                  >목재 &#47; 목공용 <br /><span>
                    목재보호의 대명사 &#39; 월드스테인 &#39;과 목공 전문 브랜드
                    &#39; 에코우드 &#39;까지 전문가가 선호하는 목재 &#47; 목공용
                    도료
                  </span></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active  mainBusiness-slide-img-05">
              <a href="#">
                <strong
                  >공업용 <br /><span
                    >다양한 색상, 고도의 내구성, 뛰어난 경제성의 공업용
                    페인트</span
                  ></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-06">
              <a href="#">
                <strong
                  >PCM용 <br /><span
                    >고급스러운 외관을 표현하는 PCM용 페인트</span
                  ></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-07">
              <a href="#">
                <strong
                  >분체용 <br /><span>
                    국내 &#183; 외 산업계에 생산 공급하는 환경 친화형 분말
                    분체용 페인트
                  </span></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-08">
              <a href="#">
                <strong
                  >제관용 <br /><span
                    >식품 및 음료캔 내용물의 장기보존에 우수한 제관용
                    페인트</span
                  ></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-09">
              <a href="#">
                <strong
                  >합성수지용 <br /><span>
                    친환경 기술을 바탕으로 한 맞춤형 &#183; 고품질 합성수지용
                    페인트
                  </span></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-10">
              <a href="#">
                <strong
                  >플라스틱용 <br /><span
                    >제품의 기능성과 심미성을 책임지는 플라스틱용 페인트</span
                  ></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-11">
              <a href="#">
                <strong
                  >산업 &#47; 플랜트용 <br /><span>
                    가혹한 환경에 노출되는 설비에 필수적인 산업&#47;플래트용
                    페인트
                  </span></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-12">
              <a href="#">
                <strong
                  >폴리우레아 <br /><span
                    >세계 최고의 신기술 &#45; 초속경화형 슈퍼테크
                    폴리우레아</span
                  ></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-13">
              <a href="#">
                <strong
                  >자동차용 <br /><span
                    >자동차가 꿈꾸는 미라클, 카로클</span
                  ></strong
                >
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-14">
              <a href="#">
                <strong
                  >반려동물 전용 <br /><span
                    >반려동물에게 안전한 PS인증 제품</span
                  ></strong
                >
              </a>
            </li>
          </ul>
          <!--mainbusiness_slider01-->
        </div>
        <!-- mainbusiness_slider_wrap01 -->

        <div class="mainbusiness_slider_wrap02">
          <ul class="mainbusiness_slider02">
            <li class="mainbusiness_slider_active mainBusiness-slide-img-02">
              <a href="#">
                <strong>방수 &#47; 바닥용 </strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-03">
              <a href="#"> <strong>내화 &#47; 방염</strong></a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-04">
              <a href="#">
                <strong>목재 &#47; 목공용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active  mainBusiness-slide-img-05">
              <a href="#">
                <strong>공업용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-06">
              <a href="#">
                <strong>PCM용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-07">
              <a href="#">
                <strong>분체용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-08">
              <a href="#">
                <strong>제관용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-09">
              <a href="#">
                <strong>합성수지용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-10">
              <a href="#">
                <strong>플라스틱용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-11">
              <a href="#">
                <strong>산업 &#47; 플랜트용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-12">
              <a href="#">
                <strong>폴리우레아</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-13">
              <a href="#">
                <strong>자동차용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-14">
              <a href="#">
                <strong>반려동물 전용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-01">
              <a href="#"> <strong>건축용</strong></a>
            </li>
          </ul>
          <!--mainbusiness_slider02-->
        </div>
        <!-- mainbusiness_slider_wrap02 -->

        <div class="mainbusiness_slider_wrap03">
          <ul class="mainbusiness_slider03">
            <li class="mainbusiness_slider_active mainBusiness-slide-img-03">
              <a href="#"> <strong>내화 &#47; 방염</strong></a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-04">
              <a href="#">
                <strong>목재 &#47; 목공용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active  mainBusiness-slide-img-05">
              <a href="#">
                <strong>공업용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-06">
              <a href="#">
                <strong>PCM용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-07">
              <a href="#">
                <strong>분체용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-08">
              <a href="#">
                <strong>제관용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-09">
              <a href="#">
                <strong>합성수지용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-10">
              <a href="#">
                <strong>플라스틱용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-11">
              <a href="#">
                <strong>산업 &#47; 플랜트용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-12">
              <a href="#">
                <strong>폴리우레아</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-13">
              <a href="#">
                <strong>자동차용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-14">
              <a href="#">
                <strong>반려동물 전용</strong>
              </a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-01">
              <a href="#"> <strong>건축용</strong></a>
            </li>
            <li class="mainbusiness_slider_active mainBusiness-slide-img-02">
              <a href="#">
                <strong>방수 &#47; 바닥용 </strong>
              </a>
            </li>
          </ul>
          <!--mainbusiness_slider03-->
        </div>
        <!-- mainbusiness_slider_wrap03 -->

        <div class="mainbusiness_slider_nav">
          <button type="button" class="slider_prev">
            <img src="../assets/img/icon/left_arrow.svg" alt="이전아이콘" />
          </button>
          <button type="button" class="slider_next">
            <img src="../assets/img/icon/right_arrow.svg" alt="다음아이콘" />
          </button>
        </div>
        <!--mainbusiness_slider_nav-->
      </div>
      <!-- mainbusiness_content -->
    </div>
    <!-- mainbusiness_wrap -->
  </section>
  <!-- mainBusiness -->
</template>
<script>
import $ from "jquery";
export default {
  name: "MainBusiness",
  mounted() {
    let slider_next = $(".slider_next"),
      slider_prev = $(".slider_prev"),
      zoomOutSlide_list_wrap = $(".mainbusiness_slider01"),
      zoomOutSlide_list_wrap2 = $(".mainbusiness_slider02"),
      zoomOutSlide_list_wrap3 = $(".mainbusiness_slider03"),
      zoomOutSlide_list = $(".mainbusiness_slider01 li"),
      zoomOutSlide_list2 = $(".mainbusiness_slider02 li");

    var slidewidth = 580 * zoomOutSlide_list.length + "px"; //580*li 개수
    zoomOutSlide_list_wrap.css("width", slidewidth); //580*14 = 8120px//alert(slidewidth);
    $(".mainbusiness_slider01 li:last").prependTo(zoomOutSlide_list_wrap); //마지막 li를 맨앞으로 이동
    zoomOutSlide_list_wrap.css("margin-left", "-580px");

    var slidewidth2 = 480 * zoomOutSlide_list2.length + "px"; //480*li 개수
    zoomOutSlide_list_wrap2.css("width", slidewidth); //480*14
    $(".mainbusiness_slider02 li:last").prependTo(zoomOutSlide_list_wrap2); //마지막 li를 맨앞으로 이동
    zoomOutSlide_list_wrap2.css("margin-left", "-480px");

    var slidewidth3 = 480 * zoomOutSlide_list2.length + "px"; //480*li 개수
    zoomOutSlide_list_wrap3.css("width", slidewidth); //480*14
    $(".mainbusiness_slider03 li:last").prependTo(zoomOutSlide_list_wrap3); //마지막 li를 맨앞으로 이동
    zoomOutSlide_list_wrap3.css("margin-left", "-480px");

    slider_next.click(function() {
      $(".mainbusiness_slider01:not(:animated)").animate(
        {
          marginLeft:
            parseInt(zoomOutSlide_list_wrap.css("margin-left")) - 580 + "px"
        },
        "slow",
        "swing",
        function() {
          $(".mainbusiness_slider01 li:first").appendTo(zoomOutSlide_list_wrap); //맨앞 li를 맨뒤로 이동
          zoomOutSlide_list_wrap.css("margin-left", "-580px");
        }
      );
      $(".mainbusiness_slider02:not(:animated)").animate(
        {
          marginLeft:
            parseInt(zoomOutSlide_list_wrap2.css("margin-left")) - 480 + "px"
        },
        "slow",
        "swing",
        function() {
          $(".mainbusiness_slider02 li:first").appendTo(
            zoomOutSlide_list_wrap2
          ); //맨앞 li를 맨뒤로 이동
          zoomOutSlide_list_wrap2.css("margin-left", "-480px");
        }
      );
      $(".mainbusiness_slider03:not(:animated)").animate(
        {
          marginLeft:
            parseInt(zoomOutSlide_list_wrap3.css("margin-left")) - 480 + "px"
        },
        "slow",
        "swing",
        function() {
          $(".mainbusiness_slider03 li:first").appendTo(
            zoomOutSlide_list_wrap3
          ); //맨앞 li를 맨뒤로 이동
          zoomOutSlide_list_wrap3.css("margin-left", "-480px");
        }
      );
    });

    slider_prev.click(function() {
      /////1번 ul
      $(".mainbusiness_slider01:not(:animated)").animate(
        {
          marginLeft:
            parseInt(zoomOutSlide_list_wrap.css("margin-left")) + 580 + "px"
        },
        "slow",
        "swing",
        function() {
          $(".mainbusiness_slider01 li:last").prependTo(zoomOutSlide_list_wrap); //맨앞 li를 맨뒤로 이동
          zoomOutSlide_list_wrap.css("margin-left", "-580px");
        }
      );
      /////2번 ul
      $(".mainbusiness_slider02:not(:animated)").animate(
        {
          marginLeft:
            parseInt(zoomOutSlide_list_wrap2.css("margin-left")) + 480 + "px"
        },
        "slow",
        "swing",
        function() {
          $(".mainbusiness_slider02 li:last").prependTo(
            zoomOutSlide_list_wrap2
          ); //맨앞 li를 맨뒤로 이동
          zoomOutSlide_list_wrap2.css("margin-left", "-480px");
        }
      );
      /////3번 ul
      $(".mainbusiness_slider03:not(:animated)").animate(
        {
          marginLeft:
            parseInt(zoomOutSlide_list_wrap3.css("margin-left")) + 480 + "px"
        },
        "slow",
        "swing",
        function() {
          $(".mainbusiness_slider03 li:last").prependTo(
            zoomOutSlide_list_wrap3
          ); //맨앞 li를 맨뒤로 이동
          zoomOutSlide_list_wrap3.css("margin-left", "-480px");
        }
      );
    });
  }
};
</script>
<style scoped>
/* mainBusiness */
#mainBusiness {
  width: 100%;
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  overflow: hidden;
  background-color: white;
}
#mainBusiness h3 {
  font-size: 80px;
  font-family: "Playfair Display", serif;
  width: 100%;
  height: 184px;
  font-weight: 500;
}
.mainbusiness_wrap {
  width: 1180px;
  height: 1300px;
  padding: 160px 0 240px 0;
}

.mainbusiness_content {
  width: 100%;
  height: 1110px;
  position: relative;
}

.mainbusiness_content p {
  font-size: 20px;
  position: absolute;
  top: -140px;
  left: 200px;
  line-height: 36px;
  font-family: "Noto", sans-serif;
  z-index: 1;
  color: #6e6e6e;
}

/* mainbusiness_slider_wrap01 */
.mainbusiness_slider_wrap01 {
  width: 580px;
  height: 870px;
  margin-top: 200px;
  overflow: hidden;
}

.mainbusiness_slider01 {
  width: 580px;
  height: 100%;
}

.mainbusiness_slider01 > li {
  width: 580px;
  height: 100%;
  float: left;
  position: relative;
}

/* mainbusiness_slider_wrap02 */
.mainbusiness_slider_wrap02 {
  width: 480px;
  height: 720px;
  overflow: hidden;
  position: absolute;
  top: -140px;
  right: 60px;
}

.mainbusiness_slider02 {
  width: 480px;
  height: 100%;
}

.mainbusiness_slider02 > li {
  width: 480px;
  height: 100%;
  float: left;
  position: relative;
}

/* mainbusiness_slider_wrap03 */
.mainbusiness_slider_wrap03 {
  width: 480px;
  height: 720px;
  overflow: hidden;
  position: absolute;
  top: 0;
  right: -480px;
}

.mainbusiness_slider03 {
  width: 480px;
  height: 100%;
}

.mainbusiness_slider03 > li {
  width: 480px;
  height: 100%;
  float: left;
  position: relative;
}

.mainBusiness-slide-img-01 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-01.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-02 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-02.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-03 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-03.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-04 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-04.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-05 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-05.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-06 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-06.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-07 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-07.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-08 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-08.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-09 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-09.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-10 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-10.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-11 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-11.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-12 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-12.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-13 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-13.jpg)
    no-repeat center / contain;
}

.mainBusiness-slide-img-14 {
  background: url(../assets/img/thumbnail/mainBusiness-slide-img-14.jpg)
    no-repeat center / contain;
}

.mainbusiness_slider_active > a > strong {
  position: absolute;
  bottom: 40px;
  left: 0;
  font-size: 40px;
  padding: 0 40px;
  color: #fff;
  letter-spacing: -1px;
  display: block;
}

.mainbusiness_slider_active > a > strong > span {
  display: block;
  font-size: 22px;
  margin-top: 15px;
  margin-bottom: 8px;
  line-height: 36px;
  letter-spacing: -2px;
}

.mainbusiness_slider_active img {
  width: 100%;
  height: 100%;
}

.mainbusiness_slider_nav {
  position: absolute;
  bottom: 400px;
  right: 400px;
  width: 140px;
  height: 62px;
  display: flex;
  justify-content: space-between;
}

.mainbusiness_slider_nav button {
  outline: none;
  border: 1px solid #000;
  border-radius: 50px;
  font-size: 0;
  cursor: pointer;
  background: none;
}
.mainbusiness_slider_nav button:hover {
  background: #000;
}

.slider_prev {
  width: 62px;
  height: 62px;
}

.slider_prev:hover img {
  filter: invert(10);
}

.slider_next {
  width: 62px;
  height: 62px;
}
.slider_next:hover img {
  filter: invert(10);
}
</style>

module.exports={
  mode: 'development',
  entry: {
    main: './src/app.js'
  },
  output: {
  path: path.realve('./dist'),
  filename: '[name].js',
  }
}
<template>
  <div class="maincolor_list_info">
    <!-- /////FullScreenColor는 보라색카드 hover시 나오는 팝업창입니다!!!//// -->
    <transition name="fade">
      <FullScreenColor
        v-if="FullScreenColor === true"
        @close="colorFullScreenCloseActive"
        :color="color"
    /></transition>
    <!-- @mouseover="popBtnShow(index)" -->
    <span :style="{background: color.colorRgbCode}" >
      <ColorPopBtn @child="colorFullScreenActive" :color="color" />
    </span>
    <!-- span에 background-color로 !!colorRgbCode!!가 들어가야합니다..ㅠㅠ -->
    <p>{{ color.colorName }}<!--{{ colorName }}--></p>
    <!-- p태그에 colorName이 들어가야합니다..! -->
    <i>{{ color.colorCode }}<!-- {{ colorName }} --></i>
    <!-- span태그에 colorCode이 들어가야합니다..! -->
    
  </div>
</template>
<script>
import $ from "jquery";
import ColorPopBtn from "../components/button/ColorPopBtn";
import FullScreenColor from "../components/popup/FullScreenColor";

export default {
  data() {
    return {
      FullScreenColor: false,
      colorCodeCopyListBtn: false,
      colorName: "",
      colorCode: ""
    };
  },
  props: {
    color: Object,
    index: Number,
  },
  methods: {
    colorFullScreenActive: function(val) {
      console.log(val);
      this.FullScreenColor = val;
    },
    colorFullScreenCloseActive: function(val) {
      console.log(val);
      $(".color_pop_btnwrap").hide();
      this.FullScreenColor = false;
    },
  },
  components: {
    ColorPopBtn,
    FullScreenColor
  }
};
</script>
<style scoped>
.maincolor_list_info {
  width: 282px;
  height: 358px;
  position: absolute;
  top: 0;
  left: 0;
  padding: 4px;
}

.maincolor_list_info span {
  width: 282px;
  height: 272px;
  display: block;
  position: relative;
  background-color: rgb(85, 0, 119); /*임시컬러*/
}

.maincolor_list_info {
  width: 282px;
  height: 358px;
  background: #fff;
  position: absolute;
  top: 0;
  right: 0;
  padding: 4px;
}

.maincolor_list_info span {
  width: 282px;
  height: 272px;
  display: block;
  position: relative;
}

.maincolor_list_info p {
  font-size: 20px;
  font-weight: bold;
  padding: 12px 12px 0;
  line-height: 30px;
}
.maincolor_list_info i {
  font-size: 14px;
  font-style: normal;
  font-weight: 100;
  padding: 4px 12px 20px;
  line-height: 30px;
  letter-spacing: -0.5px;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
